package jira;

import org.hamcrest.Matchers;
import org.testng.annotations.Test;

import io.restassured.response.Response;

public class GetIssue extends BaseClass{
	@Test(dependsOnMethods = "jira.UpdateIssue.updateissue")
	public  void getIssue() {
		Response response=inputRequest.get(jiraid);
		response.prettyPrint();
		System.out.println("Status Code for getIssue Method :" + response.statusCode());
		/*
		 * response.then().assertThat().body("fields.summary",
		 * Matchers.containsString("TES1"));
		 * response.then().assertThat().body("fields.summary",
		 * Matchers.equalTo("create issue in TES1 project"));
		 * response.then().assertThat().body("fields.summary",
		 * Matchers.hasItem("create issue in TES1 project"));
		 */
	}

}
