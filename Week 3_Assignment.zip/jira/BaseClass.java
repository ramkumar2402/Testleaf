package jira;

import org.testng.annotations.BeforeMethod;

import io.restassured.RestAssured;
import io.restassured.specification.RequestSpecification;

public class BaseClass {
	
	public static String jiraid;
	public static RequestSpecification inputRequest;
	
	@BeforeMethod
	public void resusuablekeys() {
		RestAssured.baseURI="https://ramkumarqa24.atlassian.net/rest/api/2/issue/";
		inputRequest=RestAssured.given()
				.auth().preemptive().basic("ramkumarqa24@gmail.com", "YwsEpe8OjuYwYFbdKshX51C1");
	}

}
