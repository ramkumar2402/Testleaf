package jira;

import org.testng.annotations.Test;

import io.restassured.response.Response;

public class DeleteIssue extends BaseClass {
	@Test(dependsOnMethods = "jira.GetIssue.getIssue")
	public void deleteIssue() {
		Response response=inputRequest.delete(jiraid);
		response.prettyPrint();
		System.out.println("StatusCode for deleteIssue Method : "+response.statusCode());
	}

}
