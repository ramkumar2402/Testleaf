package jira;

import java.io.File;

import org.testng.annotations.Test;

import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class CreateIssues extends BaseClass{
	@Test
	public void createIssues() {
		File inputdata=new File("./Data/jirapostdata.json");
		inputRequest
		.contentType(ContentType.JSON)
		.body(inputdata);
		Response response =inputRequest.post();
		//response.prettyPrint();
		System.out.println("Status Code for createIssue Method :" + response.statusCode());
		jiraid=response.jsonPath().get("id");
		System.out.println("Jira ID is :"+jiraid);
		
	}

}
