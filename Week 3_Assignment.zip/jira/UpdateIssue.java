package jira;

import java.io.File;

import org.testng.annotations.Test;

import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class UpdateIssue extends BaseClass{
	@Test(dependsOnMethods = "jira.CreateIssues.createIssues")
	public void updateissue() {
		
		
		File inputdata=new File("./Data/jiraputdata.json");
		inputRequest
		.contentType(ContentType.JSON)
		.body(inputdata);
		Response response=inputRequest.put(jiraid);
		response.prettyPrint();
		System.out.println("Status code for updateIssue Method:" + response.statusCode());
	}

}
